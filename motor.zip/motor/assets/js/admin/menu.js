function show_box_menu_admin() {
    box_menu_admin.style.display = 'block';
}