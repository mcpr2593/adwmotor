<div class="belum_login">
    <img src="<?php echo $url; ?>assets/icons/key.svg">
    <h1>Halaman memerlukan akses login.</h1>
    <a href="<?php echo $url; ?>login">
        <div class="login_belum_login">
            <p>Login Sekarang</p>
        </div>
    </a>
</div>